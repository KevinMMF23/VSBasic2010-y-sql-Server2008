﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.SqlServerCe;

namespace $safeprojectname$
{
    public partial class Maestros : Form
    {
        // Cadena de conexión a la base de datos
        private string connectionString = "Data Source=C:\\Users\\Kevin\\Desktop\\$safeprojectname$\\$safeprojectname$\\base.sdf";
       
        // Variables para almacenar datos
        // Obtener los valores de los TextBox u otros controles en tu formulario
        int pk_maestro ;
        string nombre  ;
        string ap_paterno ;
        string ap_materno ;
        string matricula_empleado ;
        DateTime fecha_ingreso ;
        string email ;
        string telefono ;


        public Maestros()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Obtener los valores de los TextBox u otros controles en tu formulario
            int pk_maestro = Convert.ToInt32(txtpk.Text);
            string nombre = txtnombre.Text;
            string ap_paterno = txtappPaterno.Text;
            string ap_materno = txtappMaterno.Text;
            string matricula_empleado = txtMatricula.Text;
            DateTime fecha_ingreso = DateTime.Parse(txtfecha.Text);
            string email = txtemail.Text;
            string telefono = txttelefono.Text;

            
            
            // Llamar al método ModificarMaestro con los valores obtenidos
            bool modificacionExitosa = ModificarMaestro(pk_maestro, nombre, ap_paterno, ap_materno, matricula_empleado, fecha_ingreso, email, telefono);

            if (modificacionExitosa)
            {
                MessageBox.Show("Datos del maestro modificados correctamente.");
            }
            else
            {
                MessageBox.Show("No se pudo modificar los datos del maestro.");
            }
        }

        private void Maestros_Load(object sender, EventArgs e)
        {

        }

        private bool ModificarMaestro(int pk_maestro, string nombre, string ap_paterno, string ap_materno, string matricula_empleado, DateTime fecha_ingreso, string email, string telefono)
        {
            // Consulta SQL para actualizar los datos del maestro
            string updateQuery = @"
        UPDATE tb_Maestro
        SET nombre = @nombre,
            ap_paterno = @ap_paterno,
            ap_materno = @ap_materno,
            matricula_empleado = @matricula_empleado,
            fecha_ingreso = @fecha_ingreso,
            email = @email,
            telefono = @telefono
        WHERE Pk_maestro = @pk_maestro";

            try
            {
                using (SqlCeConnection connection = new SqlCeConnection(connectionString))
                using (SqlCeCommand command = new SqlCeCommand(updateQuery, connection))
                {
                    // Asigna valores a los parámetros
                    command.Parameters.AddWithValue("@nombre", nombre);
                    command.Parameters.AddWithValue("@ap_paterno", ap_paterno);
                    command.Parameters.AddWithValue("@ap_materno", ap_materno);
                    command.Parameters.AddWithValue("@matricula_empleado", matricula_empleado);
                    command.Parameters.AddWithValue("@fecha_ingreso", fecha_ingreso);
                    command.Parameters.AddWithValue("@email", email);
                    command.Parameters.AddWithValue("@telefono", telefono);
                    command.Parameters.AddWithValue("@pk_maestro", pk_maestro);

                    connection.Open();
                    int rowsAffected = command.ExecuteNonQuery();
                    return rowsAffected > 0;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al intentar modificar los datos del maestro: " + ex.Message);
                return false;
            }
        }



        private bool AgregarMaestro(string nombre, string ap_paterno, string ap_materno, string matricula_empleado, DateTime fecha_ingreso, string email, string telefono)
        {
            // Consulta SQL para verificar si ya existe un maestro con el mismo ID
            string selectQuery = "SELECT COUNT(*) FROM tb_Maestro WHERE nombre = @nombre AND ap_paterno = @ap_paterno AND ap_materno = @ap_materno";

            try
            {
                using (SqlCeConnection connection = new SqlCeConnection(connectionString))
                using (SqlCeCommand command = new SqlCeCommand(selectQuery, connection))
                {
                    connection.Open();

                    // Asignar valores a los parámetros
                    command.Parameters.AddWithValue("@nombre", nombre);
                    command.Parameters.AddWithValue("@ap_paterno", ap_paterno);
                    command.Parameters.AddWithValue("@ap_materno", ap_materno);

                    // Ejecutar la consulta para contar el número de registros con el mismo nombre y apellidos
                    int count = (int)command.ExecuteScalar();

                    // Si ya existe un registro con el mismo nombre y apellidos, mostrar un mensaje y devolver false
                    if (count > 0)
                    {
                        MessageBox.Show("Ya existe un maestro con el mismo nombre y apellidos. No se puede agregar duplicados.");
                        return false;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al verificar la existencia del maestro: " + ex.Message);
                return false;
            }

            // Consulta SQL para insertar el nuevo maestro
            string insertQuery = @"
        INSERT INTO tb_Maestro (nombre, ap_paterno, ap_materno, matricula_empleado, fecha_ingreso, email, telefono)
        VALUES (@nombre, @ap_paterno, @ap_materno, @matricula_empleado, @fecha_ingreso, @email, @telefono)";

            try
            {
                using (SqlCeConnection connection = new SqlCeConnection(connectionString))
                using (SqlCeCommand command = new SqlCeCommand(insertQuery, connection))
                {
                    // Asignar valores a los parámetros
                    command.Parameters.AddWithValue("@nombre", nombre);
                    command.Parameters.AddWithValue("@ap_paterno", ap_paterno);
                    command.Parameters.AddWithValue("@ap_materno", ap_materno);
                    command.Parameters.AddWithValue("@matricula_empleado", matricula_empleado);
                    command.Parameters.AddWithValue("@fecha_ingreso", fecha_ingreso);
                    command.Parameters.AddWithValue("@email", email);
                    command.Parameters.AddWithValue("@telefono", telefono);

                    connection.Open();
                    int rowsAffected = command.ExecuteNonQuery();
                    return rowsAffected > 0;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al intentar agregar el maestro: " + ex.Message);
                return false;
            }
        }



        

      
        private void btnADD_Click(object sender, EventArgs e)
        {
           

            string nombre = txtnombre.Text;
            string ap_paterno = txtappPaterno.Text;
            string ap_materno = txtappMaterno.Text;
            string matricula_empleado = txtMatricula.Text;

            DateTime fecha_ingreso;
            if (!DateTime.TryParse(txtfecha.Text, out fecha_ingreso))
            {
                MessageBox.Show("La fecha de ingreso no tiene un formato válido.");
                return; // Salir del método si la conversión falla
            }

            string email = txtemail.Text;
            string telefono = txttelefono.Text;



            // Llamar al método AgregarMaestro con los valores obtenidos
            bool agregadoExitosamente = AgregarMaestro(nombre, ap_paterno, ap_materno, matricula_empleado, fecha_ingreso, email, telefono);

            if (agregadoExitosamente)
            {
                MessageBox.Show("Nuevo maestro agregado correctamente.");
                // Aquí puedes realizar otras acciones después de agregar exitosamente el maestro
            }
            else
            {
                MessageBox.Show("No se pudo agregar el nuevo maestro.");
            }
        }

      

    }



}
