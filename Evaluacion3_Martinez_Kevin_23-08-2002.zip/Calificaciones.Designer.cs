﻿namespace $safeprojectname$
{
    partial class Calificaciones
    {
        /// <summary>
        /// Variable del diseñador requerida.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén utilizando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben eliminar; false en caso contrario, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido del método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtpk = new System.Windows.Forms.TextBox();
            this.txtFKMaestro = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtFKAlumno = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.calificacion = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtFKMateria = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.observaciones = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtpk
            // 
            this.txtpk.Location = new System.Drawing.Point(153, 48);
            this.txtpk.Name = "txtpk";
            this.txtpk.Size = new System.Drawing.Size(100, 20);
            this.txtpk.TabIndex = 39;
            // 
            // txtFKMaestro
            // 
            this.txtFKMaestro.Location = new System.Drawing.Point(153, 74);
            this.txtFKMaestro.Name = "txtFKMaestro";
            this.txtFKMaestro.Size = new System.Drawing.Size(100, 20);
            this.txtFKMaestro.TabIndex = 37;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(70, 48);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(21, 13);
            this.label1.TabIndex = 36;
            this.label1.Text = "PK";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(70, 103);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(50, 13);
            this.label3.TabIndex = 41;
            this.label3.Text = "fkalumno";
            // 
            // txtFKAlumno
            // 
            this.txtFKAlumno.Location = new System.Drawing.Point(153, 100);
            this.txtFKAlumno.Name = "txtFKAlumno";
            this.txtFKAlumno.Size = new System.Drawing.Size(100, 20);
            this.txtFKAlumno.TabIndex = 40;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(70, 161);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(60, 13);
            this.label4.TabIndex = 45;
            this.label4.Text = "calificacion";
            // 
            // calificacion
            // 
            this.calificacion.Location = new System.Drawing.Point(153, 158);
            this.calificacion.Name = "calificacion";
            this.calificacion.Size = new System.Drawing.Size(100, 20);
            this.calificacion.TabIndex = 44;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(70, 135);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(50, 13);
            this.label5.TabIndex = 43;
            this.label5.Text = "fkmateria";
            // 
            // txtFKMateria
            // 
            this.txtFKMateria.Location = new System.Drawing.Point(153, 132);
            this.txtFKMateria.Name = "txtFKMateria";
            this.txtFKMateria.Size = new System.Drawing.Size(100, 20);
            this.txtFKMateria.TabIndex = 42;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(70, 74);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 13);
            this.label2.TabIndex = 46;
            this.label2.Text = "fkmaestro";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(70, 187);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(76, 13);
            this.label6.TabIndex = 48;
            this.label6.Text = "observaciones";
            // 
            // observaciones
            // 
            this.observaciones.Location = new System.Drawing.Point(153, 184);
            this.observaciones.Name = "observaciones";
            this.observaciones.Size = new System.Drawing.Size(100, 20);
            this.observaciones.TabIndex = 47;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(290, 74);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 49;
            this.button1.Text = "ADD";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(290, 125);
            this.button2.Name = "button2";
            this.button2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 50;
            this.button2.Text = "MODIFY";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(290, 161);
            this.button3.Name = "button3";
            this.button3.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 51;
            this.button3.Text = "DELETE";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // Calificaciones
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(592, 261);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.observaciones);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.calificacion);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtFKMateria);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtFKAlumno);
            this.Controls.Add(this.txtpk);
            this.Controls.Add(this.txtFKMaestro);
            this.Controls.Add(this.label1);
            this.Name = "Calificaciones";
            this.Text = "Calificaciones";
            this.Load += new System.EventHandler(this.Calificaciones_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtpk;
        private System.Windows.Forms.TextBox txtFKMaestro;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtFKAlumno;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox calificacion;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtFKMateria;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox observaciones;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
    }
}