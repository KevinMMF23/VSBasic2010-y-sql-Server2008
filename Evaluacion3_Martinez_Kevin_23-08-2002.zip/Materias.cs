﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.SqlServerCe;

namespace $safeprojectname$
{
    public partial class Materias : Form
    {
        // Cadena de conexión a la base de datos
        private string connectionString = "Data Source=C:\\Users\\Kevin\\Desktop\\$safeprojectname$\\$safeprojectname$\\base.sdf";


        public Materias()
        {
            InitializeComponent();
        }

        private void Materias_Load(object sender, EventArgs e)
        {

        }
        private bool AgregarMateria(string nombreMateria)
        {
            string insertQuery = "INSERT INTO tb_materia (nombre_materia) VALUES (@nombre_materia)";

            try
            {
                using (SqlCeConnection connection = new SqlCeConnection(connectionString))
                using (SqlCeCommand command = new SqlCeCommand(insertQuery, connection))
                {
                    command.Parameters.AddWithValue("@nombre_materia", nombreMateria);
                    connection.Open();
                    int rowsAffected = command.ExecuteNonQuery();
                    return rowsAffected > 0;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al intentar agregar la materia: " + ex.Message);
                return false;
            }
        }

        //modificar
        private bool ModificarMateria(int pkMateria, string nuevoNombreMateria)
        {
            string updateQuery = "UPDATE tb_materia SET nombre_materia = @nuevoNombreMateria WHERE pk_materia = @pkMateria";

            try
            {
                using (SqlCeConnection connection = new SqlCeConnection(connectionString))
                using (SqlCeCommand command = new SqlCeCommand(updateQuery, connection))
                {
                    command.Parameters.AddWithValue("@nuevoNombreMateria", nuevoNombreMateria);
                    command.Parameters.AddWithValue("@pkMateria", pkMateria);
                    connection.Open();
                    int rowsAffected = command.ExecuteNonQuery();
                    return rowsAffected > 0;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al intentar modificar la materia: " + ex.Message);
                return false;
            }
        }



        //metodo para eliminar
        public bool EliminarMateria(int pkMateria)
        {
            string deleteQuery = "DELETE FROM tb_materia WHERE pk_materia = @pkMateria";

            try
            {
                using (SqlCeConnection connection = new SqlCeConnection(connectionString))
                using (SqlCeCommand command = new SqlCeCommand(deleteQuery, connection))
                {
                    command.Parameters.AddWithValue("@pkMateria", pkMateria);
                    connection.Open();
                    int rowsAffected = command.ExecuteNonQuery();
                    return rowsAffected > 0;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al intentar eliminar la materia: " + ex.Message);
                return false;
            }

        }

        private void btnADD_Click(object sender, EventArgs e)
        {
            string nombreMateria = txtMateria.Text;
            bool agregadoExitoso = AgregarMateria(nombreMateria);

            if (agregadoExitoso)
            {
                MessageBox.Show("Materia agregada correctamente.");
            }
            else
            {
                MessageBox.Show("No se pudo agregar la materia.");
            }
        }

        private void btnmodify_Click(object sender, EventArgs e)
        {
            int pkMateria = Convert.ToInt32(txtpk.Text);
            string nuevoNombreMateria = txtMateria.Text;

            bool modificadoExitoso = ModificarMateria(pkMateria, nuevoNombreMateria);

            if (modificadoExitoso)
            {
                MessageBox.Show("Materia modificada correctamente.");
            }
            else
            {
                MessageBox.Show("No se pudo modificar la materia.");
            }
        }

        private void btnDel_Click(object sender, EventArgs e)
        {
            // Obtener el ID de la materia desde el TextBox txtIdMateria
            int pkMateria;
            if (!int.TryParse(txtMateria.Text, out pkMateria))
            {
                MessageBox.Show("El ID de la materia ingresado no es válido.");
                return;
            }

            // Llamar al método EliminarMateria con el ID de la materia obtenido
            bool eliminadoExitoso = EliminarMateria(pkMateria);

            if (eliminadoExitoso)
            {
                MessageBox.Show("Materia eliminada correctamente.");
            }
            else
            {
                MessageBox.Show("No se pudo eliminar la materia.");
            }
        }
    }
}
