﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.SqlServerCe;

namespace $safeprojectname$
{
    public partial class Calificaciones : Form
    {
        // Cadena de conexión a la base de datos
        private string connectionString = "Data Source=C:\\Users\\Kevin\\Desktop\\$safeprojectname$\\$safeprojectname$\\base.sdf";


        public Calificaciones()
        {
            InitializeComponent();
        }

        private void Calificaciones_Load(object sender, EventArgs e)
        {

        }

        public bool AgregarCalificacion(int fkMaestro, int fkAlumno, int fkMateria, int calificacion, string observaciones)
        {
            string insertQuery = "INSERT INTO tb_Calificaciones (fk_maestro, fk_alumno, fk_materia, calificacion, observaciones) VALUES (@fkMaestro, @fkAlumno, @fkMateria, @calificacion, @observaciones)";

            try
            {
                using (SqlCeConnection connection = new SqlCeConnection(connectionString))
                using (SqlCeCommand command = new SqlCeCommand(insertQuery, connection))
                {
                    command.Parameters.AddWithValue("@fkMaestro", fkMaestro);
                    command.Parameters.AddWithValue("@fkAlumno", fkAlumno);
                    command.Parameters.AddWithValue("@fkMateria", fkMateria);
                    command.Parameters.AddWithValue("@calificacion", calificacion);
                    command.Parameters.AddWithValue("@observaciones", observaciones);
                    connection.Open();
                    int rowsAffected = command.ExecuteNonQuery();
                    return rowsAffected > 0;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al intentar agregar la calificación: " + ex.Message);
                return false;
            }
        }

        public bool EliminarCalificacion(int pkCalificacion)
        {
            string deleteQuery = "DELETE FROM tb_Calificaciones WHERE pk_calificaciones = @pkCalificacion";

            try
            {
                using (SqlCeConnection connection = new SqlCeConnection(connectionString))
                using (SqlCeCommand command = new SqlCeCommand(deleteQuery, connection))
                {
                    command.Parameters.AddWithValue("@pkCalificacion", pkCalificacion);
                    connection.Open();
                    int rowsAffected = command.ExecuteNonQuery();
                    return rowsAffected > 0;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al intentar eliminar la calificación: " + ex.Message);
                return false;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {

            // Obtener los valores necesarios desde TextBoxes
            int fkMaestro;
            if (!int.TryParse(txtFKMaestro.Text, out fkMaestro))
            {
                MessageBox.Show("Por favor ingrese un valor válido para el maestro.");
                return;
            }

            int fkAlumno;
            if (!int.TryParse(txtFKAlumno.Text, out fkAlumno))
            {
                MessageBox.Show("Por favor ingrese un valor válido para el alumno.");
                return;
            }

            int fkMateria;
            if (!int.TryParse(txtFKMateria.Text, out fkMateria))
            {
                MessageBox.Show("Por favor ingrese un valor válido para la materia.");
                return;
            }

            int calificacion;
            if (!int.TryParse(calificacion.Text, out calificacion))
            {
                MessageBox.Show("Por favor ingrese una calificación válida.");
                return;
            }

            string observaciones = observaciones.Text;


            // Llamar al método AgregarCalificacion
          AgregarCalificacion(fkMaestro, fkAlumno, fkMateria, calificacion, observaciones);

           
        }
    }
}
