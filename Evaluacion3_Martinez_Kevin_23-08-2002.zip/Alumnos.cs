﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.SqlServerCe;

namespace $safeprojectname$
{
    public partial class Alumnos : Form
    {
        // Cadena de conexión a la base de datos
        private string connectionString = "Data Source=C:\\Users\\Kevin\\Desktop\\$safeprojectname$\\$safeprojectname$\\base.sdf";
       
        //variiables
        int pk_maestro;
        string nombre;
        string ap_paterno;
        string ap_materno;
        string matricula_alumno;
        DateTime fecha_ingreso;
        string email;
        string telefono;

        public Alumnos()
        {
            InitializeComponent();
        }

        private void Alumnos_Load(object sender, EventArgs e)
        {

        }

        private void btnADD_Click(object sender, EventArgs e)
        {

            string nombre = txtnombre.Text;
            string ap_paterno = txtappPaterno.Text;
            string ap_materno = txtappMaterno.Text;
            string matricula_alumno = txtMatricula.Text;

            DateTime fecha_ingreso;
            if (!DateTime.TryParse(txtfecha.Text, out fecha_ingreso))
            {
                MessageBox.Show("La fecha de ingreso no tiene un formato válido.");
                return; // Salir del método si la conversión falla
            }

            string email = txtemail.Text;
            string telefono = txttelefono.Text;



            // Llamar al método AgregarAlumno con los valores obtenidos
    bool agregadoExitoso = AgregarAlumno(nombre, ap_paterno, ap_materno, matricula_alumno, fecha_ingreso, email, telefono);

    if (agregadoExitoso)
    {
        MessageBox.Show("Alumno agregado correctamente.");
    }
    else
    {
        MessageBox.Show("No se pudo agregar al alumno.");
    }
}


        private bool AgregarAlumno(string nombre, string ap_paterno, string ap_materno, string matricula_alumno, DateTime fecha_ingreso, string email, string telefono)
        {
            // Consulta SQL para verificar si ya existe un alumno con la misma matrícula
            string selectQuery = "SELECT COUNT(*) FROM tb_Alumno WHERE matricula_alumno = @matricula_alumno";

            try
            {
                using (SqlCeConnection connection = new SqlCeConnection(connectionString))
                using (SqlCeCommand command = new SqlCeCommand(selectQuery, connection))
                {
                    connection.Open();

                    // Asignar valor al parámetro de la consulta
                    command.Parameters.AddWithValue("@matricula_alumno", matricula_alumno);

                    // Ejecutar la consulta para contar el número de registros con la misma matrícula
                    int count = (int)command.ExecuteScalar();

                    // Si ya existe un registro con la misma matrícula, mostrar un mensaje y devolver false
                    if (count > 0)
                    {
                        MessageBox.Show("Ya existe un alumno con la misma matrícula. No se puede agregar duplicados.");
                        return false;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al verificar la existencia del alumno: " + ex.Message);
                return false;
            }

            // Consulta SQL para insertar el nuevo alumno
            string insertQuery = @"
        INSERT INTO tb_Alumno (nombre, ap_paterno, ap_materno, matricula_alumno, fecha_ingreso, email, telefono)
        VALUES (@nombre, @ap_paterno, @ap_materno, @matricula_alumno, @fecha_ingreso, @email, @telefono)";

            try
            {
                using (SqlCeConnection connection = new SqlCeConnection(connectionString))
                using (SqlCeCommand command = new SqlCeCommand(insertQuery, connection))
                {
                    // Asignar valores a los parámetros
                    command.Parameters.AddWithValue("@nombre", nombre);
                    command.Parameters.AddWithValue("@ap_paterno", ap_paterno);
                    command.Parameters.AddWithValue("@ap_materno", ap_materno);
                    command.Parameters.AddWithValue("@matricula_alumno", matricula_alumno);
                    command.Parameters.AddWithValue("@fecha_ingreso", fecha_ingreso);
                    command.Parameters.AddWithValue("@email", email);
                    command.Parameters.AddWithValue("@telefono", telefono);

                    connection.Open();
                    int rowsAffected = command.ExecuteNonQuery();
                    return rowsAffected > 0;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al intentar agregar el alumno: " + ex.Message);
                return false;
            }
        }

        private void btnmodify_Click(object sender, EventArgs e)
        {
            int pk_alumno = Convert.ToInt32(txtpk.Text);
            string nombre = txtnombre.Text;
            string ap_paterno = txtappPaterno.Text;
            string ap_materno = txtappMaterno.Text;
            string matricula_alumno = txtMatricula.Text;

            DateTime fecha_ingreso;
            if (!DateTime.TryParse(txtfecha.Text, out fecha_ingreso))
            {
                MessageBox.Show("La fecha de ingreso no tiene un formato válido.");
                return; // Salir del método si la conversión falla
            }

            string email = txtemail.Text;
            string telefono = txttelefono.Text;


            // Llamar al método ModificarAlumno con los valores obtenidos
            bool modificadoExitoso = ModificarAlumno(pk_alumno, nombre, ap_paterno, ap_materno, matricula_alumno, fecha_ingreso, email, telefono);

            if (modificadoExitoso)
            {
                MessageBox.Show("Datos del alumno modificados correctamente.");
            }
            else
            {
                MessageBox.Show("No se pudo modificar los datos del alumno.");
            }
        }


        private bool ModificarAlumno(int pk_alumno, string nombre, string ap_paterno, string ap_materno, string matricula_alumno, DateTime fecha_ingreso, string email, string telefono)
        {
            // Consulta SQL para actualizar los datos del alumno
            string updateQuery = @"
        UPDATE tb_Alumno
        SET nombre = @nombre,
            ap_paterno = @ap_paterno,
            ap_materno = @ap_materno,
            matricula_alumno = @matricula_alumno,
            fecha_ingreso = @fecha_ingreso,
            email = @email,
            telefono = @telefono
        WHERE pk_alumno = @pk_alumno";

            try
            {
                using (SqlCeConnection connection = new SqlCeConnection(connectionString))
                using (SqlCeCommand command = new SqlCeCommand(updateQuery, connection))
                {
                    // Asignar valores a los parámetros
                    command.Parameters.AddWithValue("@nombre", nombre);
                    command.Parameters.AddWithValue("@ap_paterno", ap_paterno);
                    command.Parameters.AddWithValue("@ap_materno", ap_materno);
                    command.Parameters.AddWithValue("@matricula_alumno", matricula_alumno);
                    command.Parameters.AddWithValue("@fecha_ingreso", fecha_ingreso);
                    command.Parameters.AddWithValue("@email", email);
                    command.Parameters.AddWithValue("@telefono", telefono);
                    command.Parameters.AddWithValue("@pk_alumno", pk_alumno);

                    connection.Open();
                    int rowsAffected = command.ExecuteNonQuery();
                    return rowsAffected > 0;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al intentar modificar los datos del alumno: " + ex.Message);
                return false;
            }
        }

    }
}
